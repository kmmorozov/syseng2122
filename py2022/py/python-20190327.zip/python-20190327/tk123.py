from tkinter import *

root = Tk()
my_label = Label(root, bg='red',text='привет !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
my_label2 = Label(root, bg='green',text='пока !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
my_label.pack(side=LEFT)
my_label2.pack(side=LEFT)


root.mainloop()