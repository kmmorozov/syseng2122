import time


while True:
    print('vse ok')
    time.sleep(5)
    