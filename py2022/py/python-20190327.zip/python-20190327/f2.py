

for i in range(1,101):
    print(i)
    if i==1:
        print('ok')