a=10
b=15.8

print(type(a))
print(type(b))


c=a+b
print(c)
print(type(c))
c1=int(c)

print(c1)
print(type(c1))

