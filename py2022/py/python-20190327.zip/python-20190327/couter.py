from time import sleep as sl


for  i in range(1,100):
    print(i)
    sl(1)