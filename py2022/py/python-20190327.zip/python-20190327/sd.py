a=10
b=a
print(b)
a=11
print(b)

l1=[1,2,3,4,5,6,7]
l2=l1.copy()
print(l2)
l1.remove(4)
print(l2)
