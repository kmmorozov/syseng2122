import os

res = os.system('tar czf ~/py.tar.gz `pwd` ')

print(res)