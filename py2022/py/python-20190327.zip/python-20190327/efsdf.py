
b = 10


a = int(a)
c = b/a
print(c)