st='https://www.avito.ru/sankt-peterburg?p='
en='&q=%D0%B2%D0%B0%D0%BB%D0%B5%D0%BD%D0%BA%D0%B8'

for i in range(1,101):
    print(f'{st}{i}{en}')
    
    