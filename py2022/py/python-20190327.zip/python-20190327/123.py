

print(10/'kirill')