import os

print(os.ctermid())

print(os.name)
os.sync()
fpath=os.path.abspath('processes.py')
print(fpath)