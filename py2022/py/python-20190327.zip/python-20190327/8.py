#arr = [1,2,3,4,5,'kirill']
#print(arr[0])
#print(type(arr[5]))
#print(arr)
#arr[4]='Morozov'
#print(arr)

tup = (1,2,3,4,5)
print(tup)
print(type(tup))
print(tup[2])
tup[3]=8
print(type(tup))

