
for i in ('kirill','dmitry','vitaliy'):
    print(i)