
text='Морозов Кирилл Михайлович'


print(text.encode())