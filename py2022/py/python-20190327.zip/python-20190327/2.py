a=-10.7
b=15

a=str(a)
print(a)




print(type(a))

c=a+b
print(c)
#mname='Kirill'

print('123')
##print('------------------------------------------------')
##print(a+b)
##print('a+b')
##print(mname)
##
##type(mname)
print(c)
print(type(c))
print("-------------------------------------------------")
c=int(c)
print(c)
print(type(c))
print("-------------------------------------------------")
##mname = int(mname)
##print(mname)
##print(type(mname))




